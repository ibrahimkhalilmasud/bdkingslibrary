<?php
/**
 * Deprecated. No longer needed.
 *
 * @package WordPress
 */
_deprecated_file( basename(__FILE__), '2.1.0', null, __( 'This file no longer needs to be included.' ) );
